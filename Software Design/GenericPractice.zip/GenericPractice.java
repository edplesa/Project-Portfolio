import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class GenericPractice<T,D> {
	
	//ArrayList<T> list;
	LinkedList<T> list;
	D data;
	
	GenericPractice(D data){
		this.data = data;
		//this.list = new ArrayList<T>();
		this.list = new LinkedList<T>();
	}
	
	void storeValue(T val) {
		this.list.add(val);
	}
	
	void changeValue(T val, int index) {
		this.list.set(index, val);
	}
	
	void print() {
		if (this.list.size() == 0) {
			System.out.println("empty list");
		} 
		else {
			for (T elem : this.list) {
				System.out.println(elem);
			}
		}
	}
	
	
	
	
}
