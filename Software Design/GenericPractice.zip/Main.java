
public class Main {

	public static void main(String[] args) {
		
		GenericPractice<Integer, Integer> genTest = new GenericPractice<>(10);
		
		genTest.print();
		
		genTest.storeValue(10);
		genTest.storeValue(20);
		genTest.storeValue(30);
		
		genTest.changeValue(40, 2);
		
		genTest.print();

	}

}
