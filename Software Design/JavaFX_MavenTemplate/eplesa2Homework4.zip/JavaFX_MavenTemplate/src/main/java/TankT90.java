
public class TankT90 implements Vehicle{

	@Override
	public String whatType() {
		return ("T90 tank created and ready for shipment!");
		
	}

}