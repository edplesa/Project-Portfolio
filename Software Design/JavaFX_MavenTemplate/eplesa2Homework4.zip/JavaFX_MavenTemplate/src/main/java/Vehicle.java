
public interface Vehicle {
	String whatType();
}
