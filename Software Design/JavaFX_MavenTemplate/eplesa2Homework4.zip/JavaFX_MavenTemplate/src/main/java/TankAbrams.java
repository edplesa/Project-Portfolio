
public class TankAbrams implements Vehicle{

	@Override
	public String whatType() {
		return ("Abrams tank created and ready for shipment!");
		
	}

}