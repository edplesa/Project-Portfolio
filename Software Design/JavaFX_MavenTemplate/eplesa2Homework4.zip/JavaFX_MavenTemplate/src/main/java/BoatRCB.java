
public class BoatRCB implements Vehicle{

	@Override
	public String whatType() {
		return ("RCB attack boat created and ready for shipment!");
		
	}

}