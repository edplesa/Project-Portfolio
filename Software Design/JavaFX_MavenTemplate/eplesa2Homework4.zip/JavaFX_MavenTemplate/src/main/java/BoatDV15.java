
public class BoatDV15 implements Vehicle{

	@Override
	public String whatType() {
		return ("DV15 attack boat created and ready for shipment!");
		
	}

}