
public class JetF35 implements Vehicle{

	@Override
	public String whatType() {
		return ("F35 created and ready for shipment!");
		
	}

}
