
public class JetSU50 implements Vehicle{

	@Override
	public String whatType() {
		return ("SU50 created and ready for shipment!");
		
	}

}