public class ArrayUtil {
    private int[] intArray;
    public ArrayUtil() {

    }
    public ArrayUtil(int[] arr) {
        intArray = arr;
    }
    public int[] getIntArray() {
        return intArray;
    }

    public void setIntArray(int[] arr) {
        intArray = arr;
    }

    public int minValue() {
        if (intArray.length == 0) {
            return 0;
        }
        int min = Integer.MAX_VALUE;
        for (int elem: intArray) {
            if (elem < min) {
                min = elem;
            }
        }

        return min;
    }

    public int maxValue() {
        if (intArray.length == 0) {
            return 0;
        }
        int max = Integer.MIN_VALUE;
        for (int elem: intArray) {
            if (elem > max) {
                max = elem;
            }
        }
        return max;
    }

    public int countUniqueIntegers() {
        if (intArray.length == 0) {
            return 0;
        }
        int count = 1;
        for (int i = 1; i < intArray.length; i++){
            int j = 0;
            for (j = 0; j < i; j++){
                if (intArray[i] == intArray[j]){
                    break;
                }
            }
            if (i == j){
                count++;
            }
        }
        return count;
    }

}
