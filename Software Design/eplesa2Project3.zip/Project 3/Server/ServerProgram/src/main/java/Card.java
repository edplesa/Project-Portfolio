
public class Card {
	String suite;
	int value;
	
	Card(String theSuite, int theValue) {
		suite = theSuite;
		value = theValue;
	}
}
