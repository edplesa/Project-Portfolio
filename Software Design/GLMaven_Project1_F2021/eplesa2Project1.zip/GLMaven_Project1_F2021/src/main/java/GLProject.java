import java.util.Iterator;
import java.util.ListIterator;
/*
	Author: Edward Plesa
	Project 1: Generic Lists in Java
	Fall 2021
	CS342
	Prof. Hallenbeck
 */
public class GLProject {

	public static void main(String[] args) {
		//System.out.println("Welcome to project 1");
	}
}
